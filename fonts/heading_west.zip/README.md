# HeadingWest

Heading West is a font based on my own handwriting.

## Author

Stephan Wagner <stephanwagner.me@gmail.com> (https://stephanwagner.me)
